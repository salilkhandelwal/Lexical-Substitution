import os, sys, optparse
import tqdm
import pymagnitude
import subprocess

from lexsub import *
import os
import re

from copy import deepcopy
from pymagnitude import *
from nltk.corpus import stopwords as nltk_stopwords


DATA = '../data'

def generate_model(filename):
    generate_filename = DATA + '/' + filename

    wv = Magnitude(DATA + "/glove.6B.100d.magnitude")
    vocabQHat = set([k for k, v in wv])

    isNumber = re.compile(r'\d+.*')

    def norm_word(word):
        if isNumber.search(word.lower()):
            return '---num---'
        elif re.sub(r'\W+', '', word) == '':
            return '---punc---'
        else:
            return word.lower()

    def build_lexicon(filename):
        lexicon = {}
        for line in open(filename, 'r'):
            words = line.lower().strip().split()
            lexicon[norm_word(words[0])] = [norm_word(word) for word in words[1:]]
        return lexicon

    def copyPymagnitude(wv):
        return deepcopy({k: v for k, v in wv})

    def get_substitutability(t, s):
        score = wv.similarity(t, s)
        return score

    T = 10

    qHat = copyPymagnitude(wv)
    q = copyPymagnitude(wv)
    lexicon = build_lexicon(os.path.join(DATA, "lexicons", "wordnet-synonyms+.txt"))
    loopOn = vocabQHat.intersection(set(lexicon.keys()))

    for t in range(T):
        for word in loopOn:
            wordNeighbours = set(lexicon[word]).intersection(vocabQHat)
            cand_scores = []
            for x in wordNeighbours:
                cand_scores.append(get_substitutability(x, word))

            sorted_candidates = sorted(zip(list(wordNeighbours), cand_scores), key=lambda x: x[1], reverse=True)
            wordNeighbours = [sub for sub, score in sorted_candidates][:10]

            numNeighbours = len(wordNeighbours)

            if numNeighbours == 0:
                continue

            newVec = numNeighbours * qHat[word]

            for ppWord in wordNeighbours:
                newVec += q[ppWord]

            q[word] = newVec / (2 * numNeighbours)

    # generate text file
    with open(DATA + "/glove.6B.100d.retrofit.large.similarity.wordnet+.txt", "w") as f:
        for i, (k, v) in enumerate(q.items()):
            line = " ".join([k] + list(map(str, v)) + ["\n"])
            f.write(line)

    # generate the magnitude file
    subprocess.run(["python3", "-m", "pymagnitude.converter", "-i", "../data/glove.6B.100d.retrofit.large.similarity.wordnet+.txt", "-o", generate_filename])

class LexSub:

    def __init__(self, wvec_file, topn=10):
        self.wvecs = pymagnitude.Magnitude(wvec_file)
        self.topn = topn

    def substitutes(self, index, sentence):
        "Return ten guesses that are appropriate lexical substitutions for the word at sentence[index]."
        return(list(map(lambda k: k[0], self.wvecs.most_similar(sentence[index], topn=self.topn))))


if __name__ == '__main__':
    optparser = optparse.OptionParser()
    optparser.add_option("-i", "--inputfile", dest="input", default=os.path.join('data', 'input', 'dev.txt'), help="file to segment")
    optparser.add_option("-w", "--wordvecfile", dest="wordvecfile", default=os.path.join('data', 'glove.6B.100d.retrofit.large.similarity.wordnet+.magnitude'), help="word vectors file")
    optparser.add_option("-n", "--topn", dest="topn", default=10, help="produce these many guesses")
    optparser.add_option("-l", "--logfile", dest="logfile", default=None, help="log file for debugging")
    optparser.add_option("-g", "--generate", dest="generate", default=None, help="generate retrofit model")
    (opts, _) = optparser.parse_args()

    print

    if opts.logfile is not None:
        logging.basicConfig(filename=opts.logfile, filemode='w', level=logging.DEBUG)

    if opts.generate:
        generate_model(opts.generate)
    else:
        lexsub = LexSub(opts.wordvecfile, int(opts.topn))
        num_lines = sum(1 for line in open(opts.input,'r'))
        with open(opts.input) as f:
            for line in tqdm.tqdm(f, total=num_lines):
                fields = line.strip().split('\t')
                print(" ".join(lexsub.substitutes(int(fields[0].strip()), fields[1].strip().split())))
